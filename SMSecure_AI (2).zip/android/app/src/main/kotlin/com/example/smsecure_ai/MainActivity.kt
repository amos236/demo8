package com.example.smsecure_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
