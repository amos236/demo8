import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirebaseAuthService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // ==============================
  // REGISTER
  // ==============================

  static Future<Map<String, dynamic>> register(
    String name,
    String email,
    String password,
  ) async {
    try {
      final UserCredential credential =
          await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );

      final User? user = credential.user;

      if (user == null) {
        return {
          "success": false,
          "message": "Registration failed",
        };
      }

      await user.updateDisplayName(name.trim());

      await _firestore.collection("users").doc(user.uid).set({
        "name": name.trim(),
        "email": email.trim(),
        "createdAt": FieldValue.serverTimestamp(),
      });

      return {
        "success": true,
        "user_id": user.uid,
        "name": name.trim(),
        "email": email.trim(),
      };
    } on FirebaseAuthException catch (e) {
      return {
        "success": false,
        "message": _authError(e.code),
      };
    } catch (e) {
      return {
        "success": false,
        "message": "Registration failed",
        "error": e.toString(),
      };
    }
  }

  // ==============================
  // LOGIN
  // ==============================

  static Future<Map<String, dynamic>> login(
    String email,
    String password,
  ) async {
    try {
      final UserCredential credential = await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );

      final User? user = credential.user;

      if (user == null) {
        return {
          "success": false,
          "message": "Login failed",
        };
      }

      return {
        "success": true,
        "user_id": user.uid,
        "name": user.displayName ?? "",
        "email": user.email ?? email.trim(),
      };
    } on FirebaseAuthException catch (e) {
      return {
        "success": false,
        "message": _authError(e.code),
      };
    } catch (e) {
      return {
        "success": false,
        "message": "Login failed",
        "error": e.toString(),
      };
    }
  }

  // ==============================
  // LOGOUT
  // ==============================

  static Future<void> logout() async {
    await _auth.signOut();
  }

  // ==============================
  // CURRENT USER
  // ==============================

  static User? get currentUser {
    return _auth.currentUser;
  }

  // ==============================
  // FIREBASE ERROR
  // ==============================

  static String _authError(String code) {
    switch (code) {
      case "email-already-in-use":
        return "Email is already registered";

      case "invalid-email":
        return "Invalid email address";

      case "weak-password":
        return "Password is too weak";

      case "user-not-found":
        return "Invalid email or password";

      case "wrong-password":
      case "invalid-credential":
        return "Invalid email or password";

      case "network-request-failed":
        return "Unable to connect to Firebase";

      case "too-many-requests":
        return "Too many attempts. Try again later";

      default:
        return "Authentication failed";
    }
  }
}
