import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = "https://sms-spam-detection-r0qn.onrender.com";

  // =========================================================
  // LOGIN
  // =========================================================

  static Future<Map<String, dynamic>> login(
    String email,
    String password,
  ) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/login"),
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: jsonEncode({
          "email": email,
          "password": password,
        }),
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        if (data["user_id"] != null) {
          return {
            "success": true,
            "data": data,
          };
        }

        return {
          "success": false,
          "message": data["message"] ?? "Login failed",
        };
      }

      return {
        "success": false,
        "message": data["message"] ?? "Login failed",
      };
    } catch (e) {
      return {
        "success": false,
        "message": "Unable to connect to server",
        "error": e.toString(),
      };
    }
  }

  // =========================================================
  // REGISTER
  // =========================================================

  static Future<Map<String, dynamic>> register(
    String name,
    String email,
    String password,
  ) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/register"),
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: jsonEncode({
          "name": name,
          "email": email,
          "password": password,
        }),
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        if (data["user_id"] != null) {
          return {
            "success": true,
            "data": data,
          };
        }

        return {
          "success": false,
          "message": data["message"] ?? "Registration failed",
        };
      }

      return {
        "success": false,
        "message": data["message"] ?? "Registration failed",
      };
    } catch (e) {
      return {
        "success": false,
        "message": "Unable to connect to server",
        "error": e.toString(),
      };
    }
  }

  // =========================================================
  // PREDICT SMS
  // =========================================================

  static Future<Map<String, dynamic>> predictSMS(
    String message,
    int userId,
  ) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/predict"),
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: jsonEncode({
          "message": message,
          "user_id": userId,
        }),
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        if (data["prediction"] != null) {
          return {
            "success": true,
            "data": data,
          };
        }

        return {
          "success": false,
          "message": data["message"] ?? "Prediction failed",
        };
      }

      return {
        "success": false,
        "message": data["message"] ?? "Prediction failed",
      };
    } catch (e) {
      return {
        "success": false,
        "message": "Unable to connect to server",
        "error": e.toString(),
      };
    }
  }

  // =========================================================
  // GET HISTORY
  // =========================================================

  static Future<Map<String, dynamic>> getHistory(
    int userId,
  ) async {
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/history/$userId"),
        headers: {
          "Accept": "application/json",
        },
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {
          "success": true,
          "data": data,
        };
      }

      return {
        "success": false,
        "message": data["message"] ?? "Failed to load history",
      };
    } catch (e) {
      return {
        "success": false,
        "message": "Unable to connect to server",
        "error": e.toString(),
      };
    }
  }

  // =========================================================
  // DELETE HISTORY
  // =========================================================

  static Future<Map<String, dynamic>> deleteHistory(
    int historyId,
    int userId,
  ) async {
    try {
      final response = await http.delete(
        Uri.parse("$baseUrl/history/$historyId/$userId"),
        headers: {
          "Accept": "application/json",
        },
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {
          "success": true,
          "data": data,
        };
      }

      return {
        "success": false,
        "message": data["message"] ?? "Failed to delete history",
      };
    } catch (e) {
      return {
        "success": false,
        "message": "Unable to connect to server",
        "error": e.toString(),
      };
    }
  }

  // =========================================================
  // ADMIN LOGIN
  // =========================================================

  static Future<Map<String, dynamic>> adminLogin(
    String username,
    String password,
  ) async {
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/admin/login"),
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: jsonEncode({
          "username": username,
          "password": password,
        }),
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        if (data["success"] == true) {
          return {
            "success": true,
            "data": data,
          };
        }

        return {
          "success": false,
          "message": data["message"] ?? "Admin login failed",
        };
      }

      return {
        "success": false,
        "message": data["message"] ?? "Invalid admin credentials",
      };
    } catch (e) {
      return {
        "success": false,
        "message": "Unable to connect to server",
        "error": e.toString(),
      };
    }
  }

  // =========================================================
  // ADMIN STATISTICS
  // =========================================================

  static Future<Map<String, dynamic>> getAdminStats() async {
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/admin/stats"),
        headers: {
          "Accept": "application/json",
        },
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        if (data["success"] == true) {
          return {
            "success": true,
            "data": data,
          };
        }

        return {
          "success": false,
          "message": data["message"] ?? "Failed to load admin statistics",
        };
      }

      return {
        "success": false,
        "message": data["message"] ?? "Failed to load admin statistics",
      };
    } catch (e) {
      return {
        "success": false,
        "message": "Unable to connect to server",
        "error": e.toString(),
      };
    }
  }
}
