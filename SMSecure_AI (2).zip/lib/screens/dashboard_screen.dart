import 'dart:math';

import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'login_screen.dart';

class DashboardScreen extends StatefulWidget {
  final int userId;
  final String userName;
  final String userEmail;

  const DashboardScreen({
    super.key,
    required this.userId,
    required this.userName,
    required this.userEmail,
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with SingleTickerProviderStateMixin {
  final TextEditingController messageController = TextEditingController();

  bool isLoading = false;
  bool isHistoryLoading = false;

  String prediction = "";
  double confidence = 0.0;

  List<dynamic> history = [];

  // ==============================================================
  // LIVE ROBOT WALLPAPER
  // ==============================================================

  late AnimationController backgroundAnimationController;

  final List<_Robot> robots = const [
    _Robot(size: 40, x: 0.10, y: 0.08, speed: 0.8, phase: 0.0),
    _Robot(size: 30, x: 0.30, y: 0.22, speed: 1.3, phase: 1.1),
    _Robot(size: 46, x: 0.72, y: 0.06, speed: 0.6, phase: 2.4),
    _Robot(size: 26, x: 0.90, y: 0.20, speed: 1.6, phase: 0.6),
    _Robot(size: 34, x: 0.16, y: 0.42, speed: 1.0, phase: 3.0),
    _Robot(size: 42, x: 0.52, y: 0.36, speed: 0.9, phase: 1.7),
    _Robot(size: 28, x: 0.84, y: 0.44, speed: 1.4, phase: 2.0),
    _Robot(size: 24, x: 0.05, y: 0.62, speed: 1.8, phase: 0.3),
    _Robot(size: 32, x: 0.38, y: 0.72, speed: 1.1, phase: 2.8),
    _Robot(size: 36, x: 0.68, y: 0.80, speed: 0.7, phase: 1.4),
    _Robot(size: 22, x: 0.92, y: 0.68, speed: 1.5, phase: 0.9),
  ];

  @override
  void initState() {
    super.initState();
    loadHistory();

    backgroundAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 14),
    )..repeat();
  }

  @override
  void dispose() {
    messageController.dispose();
    backgroundAnimationController.dispose();
    super.dispose();
  }

  // =========================================================
  // LOAD HISTORY
  // =========================================================

  Future<void> loadHistory() async {
    if (isHistoryLoading) return;

    setState(() {
      isHistoryLoading = true;
    });

    try {
      final result = await ApiService.getHistory(widget.userId);

      if (!mounted) return;

      if (result["success"] == true) {
        final data = result["data"];

        setState(() {
          if (data is Map && data["history"] is List) {
            history = List<dynamic>.from(data["history"]);
          } else if (data is List) {
            history = List<dynamic>.from(data);
          } else {
            history = [];
          }
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              result["message"] ?? "Failed to load history",
            ),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Unable to refresh history: $e"),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          isHistoryLoading = false;
        });
      }
    }
  }

  // =========================================================
  // PREDICT MESSAGE
  // =========================================================

  Future<void> predictMessage() async {
    final message = messageController.text.trim();

    if (message.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Please enter a message"),
          backgroundColor: Colors.orange,
        ),
      );

      return;
    }

    setState(() {
      isLoading = true;
      prediction = "";
      confidence = 0.0;
    });

    final result = await ApiService.predictSMS(
      message,
      widget.userId,
    );

    if (!mounted) return;

    setState(() {
      isLoading = false;
    });

    if (result["success"] == true) {
      final data = result["data"];

      setState(() {
        prediction = data["prediction"] ?? "";
        confidence = (data["confidence"] ?? 0).toDouble();
      });

      await loadHistory();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result["message"] ?? "Prediction failed",
          ),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // =========================================================
  // DELETE HISTORY
  // =========================================================

  Future<void> deleteHistory(int historyId) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Delete History"),
          content: const Text(
            "Are you sure you want to permanently delete this prediction?",
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context, false);
              },
              child: const Text("CANCEL"),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, true);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text("DELETE"),
            ),
          ],
        );
      },
    );

    if (confirm != true) {
      return;
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return const Center(
          child: CircularProgressIndicator(),
        );
      },
    );

    final result = await ApiService.deleteHistory(
      historyId,
      widget.userId,
    );

    if (!mounted) return;

    Navigator.pop(context);

    if (result["success"] == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            "Prediction deleted permanently",
          ),
          backgroundColor: Colors.green,
        ),
      );

      await loadHistory();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result["message"] ?? "Failed to delete",
          ),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // =========================================================
  // LOGOUT
  // =========================================================

  void logout() {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (context) => const LoginScreen(),
      ),
      (route) => false,
    );
  }

  // =========================================================
  // BUILD
  // =========================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),

      // =====================================================
      // APP BAR
      // =====================================================

      appBar: AppBar(
        elevation: 0,
        backgroundColor: const Color(0xFF5E35B1),
        foregroundColor: Colors.white,
        title: const Text(
          "SMSecure AI",
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          // REFRESH
          IconButton(
            onPressed: isHistoryLoading
                ? null
                : () async {
                    await loadHistory();

                    if (!mounted) return;

                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text("History refreshed"),
                        backgroundColor: Colors.green,
                        duration: Duration(seconds: 2),
                      ),
                    );
                  },
            icon: isHistoryLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2,
                    ),
                  )
                : const Icon(Icons.refresh),
            tooltip: "Refresh history",
          ),

          // LOGOUT
          IconButton(
            onPressed: logout,
            icon: const Icon(Icons.logout),
            tooltip: "Logout",
          ),
        ],
      ),

      // =====================================================
      // BODY
      // =====================================================

      body: Stack(
        children: [
          // ==================================================
          // LIVE ROBOT WALLPAPER (animated background)
          // ==================================================

          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: backgroundAnimationController,
                builder: (context, child) {
                  return CustomPaint(
                    painter: RobotWallpaperPainter(
                      robots: robots,
                      animationValue: backgroundAnimationController.value,
                    ),
                  );
                },
              ),
            ),
          ),

          // ==================================================
          // DASHBOARD CONTENT
          // ==================================================

          RefreshIndicator(
            onRefresh: loadHistory,
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // =================================================
                  // WELCOME
                  // =================================================

                  Text(
                    "Welcome, ${widget.userName}",
                    style: const TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 5),

                  Text(
                    widget.userEmail,
                    style: const TextStyle(
                      color: Color(0xff070404),
                      fontSize: 14,
                    ),
                  ),

                  const SizedBox(height: 25),

                  // =================================================
                  // PREDICTION CARD
                  // =================================================

                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(22),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.07),
                          blurRadius: 15,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Row(
                          children: [
                            Icon(
                              Icons.security,
                              color: Color(0xFF5E35B1),
                              size: 28,
                            ),
                            SizedBox(width: 10),
                            Text(
                              "AI SMS Detection",
                              style: TextStyle(
                                fontSize: 21,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 8),

                        const Text(
                          "Enter any SMS message and our AI model will analyze it.",
                          style: TextStyle(
                            color: Colors.grey,
                          ),
                        ),

                        const SizedBox(height: 20),

                        TextField(
                          controller: messageController,
                          maxLines: 5,
                          decoration: InputDecoration(
                            hintText: "Enter SMS message here...",
                            filled: true,
                            fillColor: const Color(0xFFF7F7FA),
                            prefixIcon: const Padding(
                              padding: EdgeInsets.only(
                                bottom: 80,
                              ),
                              child: Icon(
                                Icons.message_outlined,
                                color: Color(0xFF5E35B1),
                              ),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),
                              borderSide: const BorderSide(
                                color: Color(0xFF5E35B1),
                                width: 1.5,
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 18),

                        SizedBox(
                          width: double.infinity,
                          height: 52,
                          child: ElevatedButton(
                            onPressed: isLoading ? null : predictMessage,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF5E35B1),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15),
                              ),
                            ),
                            child: isLoading
                                ? const SizedBox(
                                    height: 24,
                                    width: 24,
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                      strokeWidth: 2,
                                    ),
                                  )
                                : const Text(
                                    "ANALYZE MESSAGE",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1,
                                    ),
                                  ),
                          ),
                        ),

                        // =================================================
                        // RESULT
                        // =================================================

                        if (prediction.isNotEmpty) ...[
                          const SizedBox(height: 25),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(18),
                            decoration: BoxDecoration(
                              color: prediction == "Spam"
                                  ? Colors.red.withOpacity(0.08)
                                  : Colors.green.withOpacity(0.08),
                              borderRadius: BorderRadius.circular(15),
                              border: Border.all(
                                color: prediction == "Spam"
                                    ? Colors.red
                                    : Colors.green,
                              ),
                            ),
                            child: Column(
                              children: [
                                Icon(
                                  prediction == "Spam"
                                      ? Icons.warning_rounded
                                      : Icons.verified_rounded,
                                  size: 45,
                                  color: prediction == "Spam"
                                      ? Colors.red
                                      : Colors.green,
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  prediction,
                                  style: TextStyle(
                                    fontSize: 25,
                                    fontWeight: FontWeight.bold,
                                    color: prediction == "Spam"
                                        ? Colors.red
                                        : Colors.green,
                                  ),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  "Confidence: $confidence%",
                                  style: const TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),

                  const SizedBox(height: 30),

                  // =================================================
                  // HISTORY TITLE
                  // =================================================

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        "Prediction History",
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        "${history.length} records",
                        style: const TextStyle(
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 15),

                  // =================================================
                  // HISTORY
                  // =================================================

                  if (isHistoryLoading)
                    const Center(
                      child: Padding(
                        padding: EdgeInsets.all(30),
                        child: CircularProgressIndicator(),
                      ),
                    )
                  else if (history.isEmpty)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(30),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: const Column(
                        children: [
                          Icon(
                            Icons.history,
                            size: 50,
                            color: Colors.grey,
                          ),
                          SizedBox(height: 10),
                          Text(
                            "No prediction history",
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    )
                  else
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: history.length,
                      itemBuilder: (context, index) {
                        final item = history[index];

                        final int historyId = item["id"];

                        final String message = item["message"] ?? "";

                        final String result = item["prediction"] ?? "";

                        final double itemConfidence =
                            (item["confidence"] ?? 0).toDouble();

                        final String createdAt = item["created_at"] ?? "";

                        final bool isSpam = result == "Spam";

                        return Container(
                          margin: const EdgeInsets.only(
                            bottom: 15,
                          ),
                          padding: const EdgeInsets.all(17),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(18),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.05),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 6,
                                    ),
                                    decoration: BoxDecoration(
                                      color: isSpam
                                          ? Colors.red.withOpacity(0.1)
                                          : Colors.green.withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Text(
                                      result,
                                      style: TextStyle(
                                        color:
                                            isSpam ? Colors.red : Colors.green,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),

                                  const Spacer(),

                                  // DELETE BUTTON
                                  IconButton(
                                    onPressed: () {
                                      deleteHistory(
                                        historyId,
                                      );
                                    },
                                    icon: const Icon(
                                      Icons.delete_outline,
                                      color: Colors.red,
                                    ),
                                    tooltip: "Delete permanently",
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              Text(
                                message,
                                style: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  const Icon(
                                    Icons.analytics_outlined,
                                    size: 17,
                                    color: Colors.grey,
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    "Confidence: ${itemConfidence}%",
                                    style: const TextStyle(
                                      color: Colors.grey,
                                      fontSize: 13,
                                    ),
                                  ),
                                  const Spacer(),
                                  if (createdAt.isNotEmpty)
                                    Flexible(
                                      child: Text(
                                        createdAt,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          color: Colors.grey,
                                          fontSize: 11,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ],
                          ),
                        );
                      },
                    ),

                  const SizedBox(height: 30),

                  // =================================================
                  // SECURITY MESSAGE
                  // =================================================

                  const Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.verified_user_outlined,
                          size: 17,
                          color: Colors.green,
                        ),
                        SizedBox(width: 6),
                        Text(
                          "Protected by AI",
                          style: TextStyle(
                            color: Colors.grey,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ================================================================
// ROBOT MODEL
// ================================================================

class _Robot {
  final double size;
  final double x;
  final double y;
  final double speed;
  final double phase;

  const _Robot({
    required this.size,
    required this.x,
    required this.y,
    required this.speed,
    required this.phase,
  });
}

// ================================================================
// ROBOT WALLPAPER PAINTER
// ================================================================

class RobotWallpaperPainter extends CustomPainter {
  final List<_Robot> robots;
  final double animationValue;

  RobotWallpaperPainter({
    required this.robots,
    required this.animationValue,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    // ==============================================================
    // SOFT BACKGROUND GRADIENT
    // ==============================================================

    final Rect fullRect = Offset.zero & size;

    final Paint backgroundPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xFFEFF1FB),
          Color(0xFFE7EAF9),
        ],
      ).createShader(fullRect);

    canvas.drawRect(fullRect, backgroundPaint);

    // ==============================================================
    // FAINT CIRCUIT GRID LINES
    // ==============================================================

    final Paint gridPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = const Color(0xFF1565C0).withValues(alpha: 0.05);

    const double gridSpacing = 46;

    for (double gx = 0; gx < size.width; gx += gridSpacing) {
      canvas.drawLine(
        Offset(gx, 0),
        Offset(gx, size.height),
        gridPaint,
      );
    }

    for (double gy = 0; gy < size.height; gy += gridSpacing) {
      canvas.drawLine(
        Offset(0, gy),
        Offset(size.width, gy),
        gridPaint,
      );
    }

    // ==============================================================
    // FLOATING ROBOTS
    // ==============================================================

    for (final robot in robots) {
      final double bob = sin(
        (animationValue * 2 * pi) + robot.phase,
      );

      final double verticalMovement = bob * 10;

      final double horizontalMovement = cos(
            (animationValue * 2 * pi * 0.5) + robot.phase,
          ) *
          7;

      final double x = (robot.x * size.width) + horizontalMovement;
      final double y = (robot.y * size.height) + verticalMovement;

      final double eyeBlink =
          (sin((animationValue * 2 * pi * 3) + robot.phase * 4) + 1) / 2;

      _drawRobot(canvas, Offset(x, y), robot.size, eyeBlink);
    }
  }

  // ================================================================
  // DRAW ONE ROBOT
  // ================================================================

  void _drawRobot(
    Canvas canvas,
    Offset center,
    double size,
    double eyeBlink,
  ) {
    final Paint bodyPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = const Color(0xFF64B5F6).withValues(alpha: 0.35);

    final Paint outlinePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = size * 0.05
      ..color = const Color(0xFF1565C0).withValues(alpha: 0.45);

    final Paint accentPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = const Color(0xFF00E5FF).withValues(alpha: 0.55);

    final Paint darkPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = const Color(0xFF37325C).withValues(alpha: 0.6);

    // Antenna
    canvas.drawLine(
      center + Offset(0, -size * 0.72),
      center + Offset(0, -size * 0.98),
      outlinePaint,
    );

    canvas.drawCircle(
      center + Offset(0, -size * 1.02),
      size * 0.09,
      accentPaint,
    );

    // Head (rounded square)
    final RRect head = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: center + Offset(0, -size * 0.30),
        width: size * 1.15,
        height: size * 0.85,
      ),
      Radius.circular(size * 0.22),
    );

    canvas.drawRRect(head, bodyPaint);
    canvas.drawRRect(head, outlinePaint);

    // Eyes (blink using vertical scale)
    final double eyeHeight = (size * 0.16) * (0.25 + 0.75 * eyeBlink);

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: center + Offset(-size * 0.28, -size * 0.32),
          width: size * 0.16,
          height: eyeHeight,
        ),
        Radius.circular(size * 0.04),
      ),
      darkPaint,
    );

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: center + Offset(size * 0.28, -size * 0.32),
          width: size * 0.16,
          height: eyeHeight,
        ),
        Radius.circular(size * 0.04),
      ),
      darkPaint,
    );

    // Mouth
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: center + Offset(0, -size * 0.08),
          width: size * 0.44,
          height: size * 0.09,
        ),
        Radius.circular(size * 0.03),
      ),
      darkPaint,
    );

    // Body (trapezoid-ish rounded rect)
    final RRect body = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: center + Offset(0, size * 0.42),
        width: size * 0.95,
        height: size * 0.60,
      ),
      Radius.circular(size * 0.16),
    );

    canvas.drawRRect(body, bodyPaint);
    canvas.drawRRect(body, outlinePaint);

    // Chest light
    canvas.drawCircle(
      center + Offset(0, size * 0.40),
      size * 0.09,
      accentPaint,
    );

    // Arms
    canvas.drawLine(
      center + Offset(-size * 0.48, size * 0.28),
      center + Offset(-size * 0.68, size * 0.44),
      outlinePaint,
    );

    canvas.drawLine(
      center + Offset(size * 0.48, size * 0.28),
      center + Offset(size * 0.68, size * 0.44),
      outlinePaint,
    );
  }

  @override
  bool shouldRepaint(
    covariant RobotWallpaperPainter oldDelegate,
  ) {
    return oldDelegate.animationValue != animationValue;
  }
}
