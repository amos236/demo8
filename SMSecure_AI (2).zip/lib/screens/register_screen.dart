import 'dart:math';

import 'package:flutter/material.dart';

import '../services/firebase_auth_service.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen>
    with SingleTickerProviderStateMixin {
  final TextEditingController nameController = TextEditingController();

  final TextEditingController emailController = TextEditingController();

  final TextEditingController passwordController = TextEditingController();

  bool hidePassword = true;
  bool isLoading = false;

  // ==============================================================
  // LIVE FLYING PLANES WALLPAPER
  // ==============================================================

  late AnimationController backgroundAnimationController;

  final List<_Plane> planes = const [
    _Plane(
      size: 26,
      y: 0.08,
      speed: 0.9,
      phase: 0.0,
      reverse: false,
    ),
    _Plane(
      size: 18,
      y: 0.18,
      speed: 1.4,
      phase: 0.4,
      reverse: true,
    ),
    _Plane(
      size: 32,
      y: 0.28,
      speed: 0.6,
      phase: 0.15,
      reverse: false,
    ),
    _Plane(
      size: 20,
      y: 0.40,
      speed: 1.1,
      phase: 0.7,
      reverse: true,
    ),
    _Plane(
      size: 24,
      y: 0.52,
      speed: 0.8,
      phase: 0.55,
      reverse: false,
    ),
    _Plane(
      size: 16,
      y: 0.63,
      speed: 1.6,
      phase: 0.85,
      reverse: true,
    ),
    _Plane(
      size: 28,
      y: 0.75,
      speed: 0.7,
      phase: 0.3,
      reverse: false,
    ),
    _Plane(
      size: 19,
      y: 0.86,
      speed: 1.2,
      phase: 0.6,
      reverse: true,
    ),
  ];

  final List<_Cloud> clouds = const [
    _Cloud(
      size: 40,
      y: 0.12,
      speed: 0.25,
      phase: 0.1,
    ),
    _Cloud(
      size: 55,
      y: 0.34,
      speed: 0.18,
      phase: 0.5,
    ),
    _Cloud(
      size: 34,
      y: 0.58,
      speed: 0.30,
      phase: 0.75,
    ),
    _Cloud(
      size: 48,
      y: 0.80,
      speed: 0.20,
      phase: 0.9,
    ),
  ];

  @override
  void initState() {
    super.initState();

    backgroundAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 16),
    )..repeat();
  }

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    backgroundAnimationController.dispose();

    super.dispose();
  }

  // ==============================================================
  // REGISTER WITH FIREBASE
  // ==============================================================

  Future<void> register() async {
    final name = nameController.text.trim();
    final email = emailController.text.trim();
    final password = passwordController.text;

    // ============================================================
    // VALIDATION
    // ============================================================

    if (name.isEmpty || email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Please fill all fields',
          ),
          backgroundColor: Colors.orange,
        ),
      );

      return;
    }

    if (!email.contains('@') || !email.contains('.')) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Please enter a valid email address',
          ),
          backgroundColor: Colors.orange,
        ),
      );

      return;
    }

    if (password.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Password must contain at least 6 characters',
          ),
          backgroundColor: Colors.orange,
        ),
      );

      return;
    }

    // ============================================================
    // START LOADING
    // ============================================================

    setState(() {
      isLoading = true;
    });

    // ============================================================
    // FIREBASE REGISTER
    // ============================================================

    final result = await FirebaseAuthService.register(
      name,
      email,
      password,
    );

    if (!mounted) return;

    // ============================================================
    // STOP LOADING
    // ============================================================

    setState(() {
      isLoading = false;
    });

    // ============================================================
    // SUCCESS
    // ============================================================

    if (result["success"] == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            "Registration successful",
          ),
          backgroundColor: Colors.green,
        ),
      );

      // Return to Login screen
      Navigator.pop(context);
    }

    // ============================================================
    // ERROR
    // ============================================================

    else {
      final String message =
          result["message"]?.toString() ?? "Registration failed";

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 4),
        ),
      );
    }
  }

  // ==============================================================
  // UI
  // ==============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      body: Stack(
        children: [
          // ======================================================
          // LIVE FLYING PLANES WALLPAPER
          // ======================================================

          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: backgroundAnimationController,
                builder: (
                  context,
                  child,
                ) {
                  return CustomPaint(
                    painter: PlaneWallpaperPainter(
                      planes: planes,
                      clouds: clouds,
                      animationValue: backgroundAnimationController.value,
                    ),
                  );
                },
              ),
            ),
          ),

          // ======================================================
          // REGISTER CONTENT
          // ======================================================

          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  // =================================================
                  // TOP SECTION
                  // =================================================

                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.only(
                      top: 40,
                      bottom: 40,
                    ),
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Color(0xFF1565C0),
                          Color(0xFF5E35B1),
                          Color(0xFF8E24AA),
                        ],
                      ),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(40),
                        bottomRight: Radius.circular(40),
                      ),
                    ),
                    child: Column(
                      children: [
                        // LOGO

                        Container(
                          width: 85,
                          height: 85,
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.person_add_rounded,
                            size: 50,
                            color: Color(0xFF5E35B1),
                          ),
                        ),

                        const SizedBox(
                          height: 18,
                        ),

                        const Text(
                          'Create Account',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        const SizedBox(
                          height: 8,
                        ),

                        const Text(
                          'Join SMSecure AI',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 15,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // =================================================
                  // FORM CARD
                  // =================================================

                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(
                          24,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(
                              alpha: 0.08,
                            ),
                            blurRadius: 20,
                            offset: const Offset(
                              0,
                              8,
                            ),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Register',
                            style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          const SizedBox(
                            height: 6,
                          ),

                          const Text(
                            'Create your SMSecure AI account',
                            style: TextStyle(
                              color: Colors.grey,
                            ),
                          ),

                          const SizedBox(
                            height: 25,
                          ),

                          // =================================================
                          // NAME
                          // =================================================

                          const Text(
                            'Full Name',
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                            ),
                          ),

                          const SizedBox(
                            height: 8,
                          ),

                          TextField(
                            controller: nameController,
                            textInputAction: TextInputAction.next,
                            decoration: InputDecoration(
                              hintText: 'Enter your name',
                              prefixIcon: const Icon(
                                Icons.person_outline,
                                color: Color(
                                  0xFF5E35B1,
                                ),
                              ),
                              filled: true,
                              fillColor: const Color(
                                0xFFF7F7FA,
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(
                                  15,
                                ),
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),

                          const SizedBox(
                            height: 20,
                          ),

                          // =================================================
                          // EMAIL
                          // =================================================

                          const Text(
                            'Email Address',
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                            ),
                          ),

                          const SizedBox(
                            height: 8,
                          ),

                          TextField(
                            controller: emailController,
                            keyboardType: TextInputType.emailAddress,
                            textInputAction: TextInputAction.next,
                            decoration: InputDecoration(
                              hintText: 'Enter your email',
                              prefixIcon: const Icon(
                                Icons.email_outlined,
                                color: Color(
                                  0xFF5E35B1,
                                ),
                              ),
                              filled: true,
                              fillColor: const Color(
                                0xFFF7F7FA,
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(
                                  15,
                                ),
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),

                          const SizedBox(
                            height: 20,
                          ),

                          // =================================================
                          // PASSWORD
                          // =================================================

                          const Text(
                            'Password',
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                            ),
                          ),

                          const SizedBox(
                            height: 8,
                          ),

                          TextField(
                            controller: passwordController,
                            obscureText: hidePassword,
                            decoration: InputDecoration(
                              hintText: 'Create a password',
                              prefixIcon: const Icon(
                                Icons.lock_outline,
                                color: Color(
                                  0xFF5E35B1,
                                ),
                              ),
                              suffixIcon: IconButton(
                                onPressed: () {
                                  setState(() {
                                    hidePassword = !hidePassword;
                                  });
                                },
                                icon: Icon(
                                  hidePassword
                                      ? Icons.visibility_outlined
                                      : Icons.visibility_off_outlined,
                                ),
                              ),
                              filled: true,
                              fillColor: const Color(
                                0xFFF7F7FA,
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(
                                  15,
                                ),
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),

                          const SizedBox(
                            height: 30,
                          ),

                          // =================================================
                          // REGISTER BUTTON
                          // =================================================

                          SizedBox(
                            width: double.infinity,
                            height: 55,
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [
                                    Color(0xFF1565C0),
                                    Color(0xFF5E35B1),
                                    Color(0xFF8E24AA),
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(
                                  15,
                                ),
                              ),
                              child: ElevatedButton(
                                onPressed: isLoading ? null : register,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.transparent,
                                  disabledBackgroundColor: Colors.transparent,
                                  shadowColor: Colors.transparent,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(
                                      15,
                                    ),
                                  ),
                                ),
                                child: isLoading
                                    ? const SizedBox(
                                        width: 24,
                                        height: 24,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2.5,
                                          color: Colors.white,
                                        ),
                                      )
                                    : const Text(
                                        'CREATE ACCOUNT',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 0.8,
                                        ),
                                      ),
                              ),
                            ),
                          ),

                          const SizedBox(
                            height: 20,
                          ),

                          // =================================================
                          // LOGIN
                          // =================================================

                          Center(
                            child: TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: const Text(
                                'Already have an account? Sign In',
                                style: TextStyle(
                                  color: Color(
                                    0xFF5E35B1,
                                  ),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(
                    height: 15,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ================================================================
// PLANE MODEL
// ================================================================

class _Plane {
  final double size;
  final double y;
  final double speed;
  final double phase;
  final bool reverse;

  const _Plane({
    required this.size,
    required this.y,
    required this.speed,
    required this.phase,
    required this.reverse,
  });
}

// ================================================================
// CLOUD MODEL
// ================================================================

class _Cloud {
  final double size;
  final double y;
  final double speed;
  final double phase;

  const _Cloud({
    required this.size,
    required this.y,
    required this.speed,
    required this.phase,
  });
}

// ================================================================
// PLANE WALLPAPER PAINTER
// ================================================================

class PlaneWallpaperPainter extends CustomPainter {
  final List<_Plane> planes;
  final List<_Cloud> clouds;
  final double animationValue;

  PlaneWallpaperPainter({
    required this.planes,
    required this.clouds,
    required this.animationValue,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    // ==============================================================
    // SKY GRADIENT BACKGROUND
    // ==============================================================

    final Rect fullRect = Offset.zero & size;

    final Paint backgroundPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xFFEAF3FC),
          Color(0xFFF3F0FA),
        ],
      ).createShader(fullRect);

    canvas.drawRect(
      fullRect,
      backgroundPaint,
    );

    // ==============================================================
    // DRIFTING CLOUDS
    // ==============================================================

    for (final cloud in clouds) {
      final double travel =
          ((animationValue * cloud.speed) + cloud.phase) % 1.0;

      final double x =
          travel * (size.width + cloud.size * 3) - cloud.size * 1.5;

      final double y = cloud.y * size.height;

      _drawCloud(
        canvas,
        Offset(x, y),
        cloud.size,
      );
    }

    // ==============================================================
    // FLYING PLANES
    // ==============================================================

    for (final plane in planes) {
      final double travel =
          ((animationValue * plane.speed) + plane.phase) % 1.0;

      final double bob = sin(
            (animationValue * 2 * pi * plane.speed) + plane.phase * 8,
          ) *
          6;

      final double x = plane.reverse
          ? size.width -
              (travel * (size.width + plane.size * 4)) +
              plane.size * 2
          : (travel * (size.width + plane.size * 4)) - plane.size * 2;

      final double y = (plane.y * size.height) + bob;

      _drawPlane(
        canvas,
        Offset(x, y),
        plane.size,
        plane.reverse,
      );
    }
  }

  // ================================================================
  // DRAW ONE PLANE
  // ================================================================

  void _drawPlane(
    Canvas canvas,
    Offset center,
    double size,
    bool reverse,
  ) {
    final Paint bodyPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = const Color(
        0xFF1565C0,
      ).withValues(
        alpha: 0.55,
      );

    final Paint wingPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = const Color(
        0xFF5E35B1,
      ).withValues(
        alpha: 0.40,
      );

    canvas.save();

    canvas.translate(
      center.dx,
      center.dy,
    );

    if (reverse) {
      canvas.scale(-1, 1);
    }

    // Fuselage

    final Path fuselage = Path()
      ..moveTo(
        -size,
        0,
      )
      ..lineTo(
        size * 0.6,
        -size * 0.14,
      )
      ..lineTo(
        size,
        0,
      )
      ..lineTo(
        size * 0.6,
        size * 0.14,
      )
      ..close();

    canvas.drawPath(
      fuselage,
      bodyPaint,
    );

    // Main wing

    final Path wing = Path()
      ..moveTo(
        -size * 0.1,
        0,
      )
      ..lineTo(
        size * 0.05,
        -size * 0.55,
      )
      ..lineTo(
        size * 0.25,
        -size * 0.5,
      )
      ..lineTo(
        size * 0.15,
        0,
      )
      ..close();

    canvas.drawPath(
      wing,
      wingPaint,
    );

    // Tail fin

    final Path tail = Path()
      ..moveTo(
        -size * 0.75,
        0,
      )
      ..lineTo(
        -size * 0.55,
        -size * 0.32,
      )
      ..lineTo(
        -size * 0.42,
        -size * 0.28,
      )
      ..lineTo(
        -size * 0.55,
        0,
      )
      ..close();

    canvas.drawPath(
      tail,
      wingPaint,
    );

    // Windows

    final Paint windowPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = Colors.white.withValues(
        alpha: 0.75,
      );

    for (int i = 0; i < 3; i++) {
      canvas.drawCircle(
        Offset(
          -size * 0.1 + (i * size * 0.28),
          0,
        ),
        size * 0.07,
        windowPaint,
      );
    }

    canvas.restore();
  }

  // ================================================================
  // DRAW ONE CLOUD
  // ================================================================

  void _drawCloud(
    Canvas canvas,
    Offset center,
    double size,
  ) {
    final Paint cloudPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = Colors.white.withValues(
        alpha: 0.55,
      );

    canvas.drawCircle(
      center,
      size * 0.5,
      cloudPaint,
    );

    canvas.drawCircle(
      center +
          Offset(
            size * 0.45,
            size * 0.05,
          ),
      size * 0.38,
      cloudPaint,
    );

    canvas.drawCircle(
      center +
          Offset(
            -size * 0.45,
            size * 0.08,
          ),
      size * 0.34,
      cloudPaint,
    );

    canvas.drawCircle(
      center +
          Offset(
            size * 0.1,
            -size * 0.22,
          ),
      size * 0.32,
      cloudPaint,
    );
  }

  @override
  bool shouldRepaint(
    covariant PlaneWallpaperPainter oldDelegate,
  ) {
    return oldDelegate.animationValue != animationValue;
  }
}
