import 'package:flutter/material.dart';
import '../services/api_service.dart';

class HistoryScreen extends StatefulWidget {
  final int userId;

  const HistoryScreen({
    super.key,
    required this.userId,
  });

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  bool isLoading = true;

  List<dynamic> history = [];

  int count = 0;

  @override
  void initState() {
    super.initState();
    loadHistory();
  }

  Future<void> loadHistory() async {
    setState(() {
      isLoading = true;
    });

    final result = await ApiService.getHistory(widget.userId);

    if (!mounted) return;

    if (result["success"] == true) {
      final data = result["data"];

      setState(() {
        history = data["history"] ?? [];
        count = data["count"] ?? 0;
        isLoading = false;
      });
    } else {
      setState(() {
        isLoading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result["message"] ?? "Failed to load history",
          ),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> refreshHistory() async {
    await loadHistory();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      appBar: AppBar(
        title: const Text(
          "Prediction History",
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        foregroundColor: Colors.white,
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xFF1565C0),
                Color(0xFF5E35B1),
                Color(0xFF8E24AA),
              ],
            ),
          ),
        ),
        actions: [
          IconButton(
            onPressed: refreshHistory,
            icon: const Icon(
              Icons.refresh,
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: refreshHistory,
        child: isLoading
            ? const Center(
                child: CircularProgressIndicator(
                  color: Color(0xFF5E35B1),
                ),
              )
            : history.isEmpty
                ? buildEmptyHistory()
                : Column(
                    children: [
                      const SizedBox(height: 15),

                      // COUNT CARD
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                        ),
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [
                                Color(0xFF1565C0),
                                Color(0xFF5E35B1),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(18),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(
                                  alpha: 0.08,
                                ),
                                blurRadius: 15,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 55,
                                height: 55,
                                decoration: BoxDecoration(
                                  color: Colors.white.withValues(alpha: 0.20),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.history,
                                  color: Colors.white,
                                  size: 30,
                                ),
                              ),
                              const SizedBox(width: 15),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    "Total Predictions",
                                    style: TextStyle(
                                      color: Colors.white70,
                                      fontSize: 14,
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    "$count",
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 25,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 15),

                      Expanded(
                        child: ListView.builder(
                          padding: const EdgeInsets.fromLTRB(
                            16,
                            0,
                            16,
                            20,
                          ),
                          itemCount: history.length,
                          itemBuilder: (context, index) {
                            final item = history[index];

                            return buildHistoryCard(item);
                          },
                        ),
                      ),
                    ],
                  ),
      ),
    );
  }

  Widget buildHistoryCard(dynamic item) {
    final String prediction = item["prediction"] ?? "Unknown";

    final bool isSpam = prediction.toLowerCase() == "spam";

    final double confidence = (item["confidence"] ?? 0).toDouble();

    final String message = item["message"] ?? "";

    final String createdAt = item["created_at"] ?? "";

    return Container(
      margin: const EdgeInsets.only(
        bottom: 14,
      ),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(
              alpha: 0.06,
            ),
            blurRadius: 12,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // TOP ROW
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: isSpam
                      ? Colors.red.withValues(
                          alpha: 0.10,
                        )
                      : Colors.green.withValues(
                          alpha: 0.10,
                        ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      isSpam
                          ? Icons.warning_rounded
                          : Icons.check_circle_rounded,
                      size: 17,
                      color: isSpam ? Colors.red : Colors.green,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      prediction,
                      style: TextStyle(
                        color: isSpam ? Colors.red : Colors.green,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              Text(
                "#${item["id"] ?? ""}",
                style: const TextStyle(
                  color: Colors.grey,
                  fontSize: 12,
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // MESSAGE
          Text(
            message,
            maxLines: 4,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 15,
              height: 1.4,
              fontWeight: FontWeight.w500,
            ),
          ),

          const SizedBox(height: 14),

          const Divider(
            height: 1,
          ),

          const SizedBox(height: 12),

          // BOTTOM INFORMATION
          Row(
            children: [
              const Icon(
                Icons.analytics_outlined,
                size: 18,
                color: Color(0xFF5E35B1),
              ),
              const SizedBox(width: 6),
              Text(
                "Confidence: ${confidence.toStringAsFixed(2)}%",
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF5E35B1),
                ),
              ),
              const Spacer(),
              const Icon(
                Icons.access_time,
                size: 16,
                color: Colors.grey,
              ),
              const SizedBox(width: 5),
              Flexible(
                child: Text(
                  createdAt,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Colors.grey,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget buildEmptyHistory() {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.20,
        ),
        const Icon(
          Icons.history_rounded,
          size: 90,
          color: Colors.grey,
        ),
        const SizedBox(height: 20),
        const Center(
          child: Text(
            "No Prediction History",
            style: TextStyle(
              fontSize: 21,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        const SizedBox(height: 8),
        const Center(
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: 40,
            ),
            child: Text(
              "Your analyzed messages will appear here.",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.grey,
                fontSize: 14,
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),
        const Center(
          child: Icon(
            Icons.keyboard_arrow_down,
            color: Colors.grey,
          ),
        ),
        const Center(
          child: Text(
            "Pull down to refresh",
            style: TextStyle(
              color: Colors.grey,
              fontSize: 12,
            ),
          ),
        ),
      ],
    );
  }
}
