import 'dart:math';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'register_screen.dart';
import '../services/api_service.dart';
import 'dashboard_screen.dart';
import 'admin_dashboard_screen.dart';

// ================================================================
// LOGIN SCREEN
// ================================================================

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

// ================================================================
// LOGIN STATE
// ================================================================

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  final TextEditingController emailController = TextEditingController();

  final TextEditingController passwordController = TextEditingController();

  bool hidePassword = true;
  bool isLoading = false;

  // Hidden admin click counter
  int signInClickCount = 0;

  late AnimationController animationController;

  // ==============================================================
  // FIREBASE
  // ==============================================================

  final FirebaseAuth _auth = FirebaseAuth.instance;

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // ==============================================================
  // LIVE PANDA WALLPAPER DATA
  // ==============================================================

  final List<_Panda> pandas = const [
    _Panda(
      size: 46,
      x: 0.10,
      y: 0.14,
      speed: 0.8,
      phase: 0.0,
    ),
    _Panda(
      size: 34,
      x: 0.30,
      y: 0.30,
      speed: 1.3,
      phase: 1.1,
    ),
    _Panda(
      size: 52,
      x: 0.72,
      y: 0.18,
      speed: 0.6,
      phase: 2.4,
    ),
    _Panda(
      size: 30,
      x: 0.88,
      y: 0.36,
      speed: 1.6,
      phase: 0.6,
    ),
    _Panda(
      size: 40,
      x: 0.18,
      y: 0.58,
      speed: 1.0,
      phase: 3.0,
    ),
    _Panda(
      size: 48,
      x: 0.50,
      y: 0.68,
      speed: 0.9,
      phase: 1.7,
    ),
    _Panda(
      size: 32,
      x: 0.80,
      y: 0.62,
      speed: 1.4,
      phase: 2.0,
    ),
    _Panda(
      size: 28,
      x: 0.06,
      y: 0.82,
      speed: 1.8,
      phase: 0.3,
    ),
  ];

  final List<_Leaf> leaves = const [
    _Leaf(
      size: 14,
      x: 0.15,
      y: 0.05,
      speed: 0.7,
      phase: 0.2,
    ),
    _Leaf(
      size: 10,
      x: 0.40,
      y: 0.10,
      speed: 1.1,
      phase: 1.5,
    ),
    _Leaf(
      size: 16,
      x: 0.65,
      y: 0.02,
      speed: 0.9,
      phase: 2.2,
    ),
    _Leaf(
      size: 12,
      x: 0.85,
      y: 0.08,
      speed: 1.3,
      phase: 0.9,
    ),
    _Leaf(
      size: 11,
      x: 0.25,
      y: 0.45,
      speed: 1.0,
      phase: 1.9,
    ),
    _Leaf(
      size: 15,
      x: 0.60,
      y: 0.50,
      speed: 0.8,
      phase: 2.7,
    ),
    _Leaf(
      size: 9,
      x: 0.95,
      y: 0.55,
      speed: 1.5,
      phase: 0.5,
    ),
  ];

  // ==============================================================
  // INIT
  // ==============================================================

  @override
  void initState() {
    super.initState();

    animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();
  }

  // ==============================================================
  // DISPOSE
  // ==============================================================

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    animationController.dispose();

    super.dispose();
  }

  // ==============================================================
  // NORMAL USER LOGIN
  // ==============================================================

  Future<void> login() async {
    final String email = emailController.text.trim();

    final String password = passwordController.text;

    // --------------------------------------------------------------
    // VALIDATION
    // --------------------------------------------------------------

    if (email.isEmpty) {
      _showMessage(
        'Please enter your email address',
        Colors.orange,
      );
      return;
    }

    if (password.isEmpty) {
      _showMessage(
        'Please enter your password',
        Colors.orange,
      );
      return;
    }

    if (!mounted) return;

    setState(() {
      isLoading = true;
    });

    try {
      // ============================================================
      // FIREBASE LOGIN
      // ============================================================

      final UserCredential userCredential =
          await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      final User? firebaseUser = userCredential.user;

      if (firebaseUser == null) {
        throw Exception(
          'Firebase user is null',
        );
      }

      // ============================================================
      // GET USER INFORMATION FROM FIRESTORE
      // ============================================================

      final DocumentSnapshot<Map<String, dynamic>> userDocument =
          await _firestore.collection('users').doc(firebaseUser.uid).get();

      if (!userDocument.exists) {
        await _auth.signOut();

        if (!mounted) return;

        setState(() {
          isLoading = false;
        });

        _showMessage(
          'User profile not found',
          Colors.red,
        );

        return;
      }

      final Map<String, dynamic>? userData = userDocument.data();

      if (userData == null) {
        await _auth.signOut();

        if (!mounted) return;

        setState(() {
          isLoading = false;
        });

        _showMessage(
          'User profile data not found',
          Colors.red,
        );

        return;
      }

      // ============================================================
      // GET USER DETAILS
      // ============================================================

      final dynamic backendUserIdValue = userData['backendUserId'];

      final String userName = userData['name']?.toString() ?? 'User';

      final String userEmail = userData['email']?.toString() ?? email;

      // ============================================================
      // USER ID CHECK
      // ============================================================

      if (backendUserIdValue == null) {
        await _auth.signOut();

        if (!mounted) return;

        setState(() {
          isLoading = false;
        });

        _showMessage(
          'User ID is missing from Firebase profile',
          Colors.red,
        );

        return;
      }

      final int? userId = int.tryParse(
        backendUserIdValue.toString(),
      );

      if (userId == null) {
        await _auth.signOut();

        if (!mounted) return;

        setState(() {
          isLoading = false;
        });

        _showMessage(
          'Invalid user ID in Firebase profile',
          Colors.red,
        );

        return;
      }

      // ============================================================
      // LOGIN SUCCESS
      // ============================================================

      if (!mounted) return;

      setState(() {
        isLoading = false;
      });

      _showMessage(
        'Login successful!',
        Colors.green,
      );

      await Future.delayed(
        const Duration(
          milliseconds: 300,
        ),
      );

      if (!mounted) return;

      // ============================================================
      // OPEN DASHBOARD
      // ============================================================

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => DashboardScreen(
            userId: userId,
            userName: userName,
            userEmail: userEmail,
          ),
        ),
      );
    }

    // ============================================================
    // FIREBASE AUTH ERRORS
    // ============================================================

    on FirebaseAuthException catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
      });

      String message;

      switch (e.code) {
        case 'invalid-credential':
        case 'wrong-password':
        case 'user-not-found':
          message = 'Invalid email or password';
          break;

        case 'invalid-email':
          message = 'Invalid email address';
          break;

        case 'user-disabled':
          message = 'This account has been disabled';
          break;

        case 'too-many-requests':
          message = 'Too many attempts. Please try again later';
          break;

        case 'network-request-failed':
          message = 'Please check your internet connection';
          break;

        case 'operation-not-allowed':
          message = 'Email/password login is not enabled in Firebase';
          break;

        default:
          message = e.message ?? 'Login failed';
      }

      _showMessage(
        message,
        Colors.red,
      );

      debugPrint(
        'FIREBASE LOGIN ERROR: ${e.code} - ${e.message}',
      );
    }

    // ============================================================
    // OTHER ERRORS
    // ============================================================

    catch (e, stackTrace) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
      });

      _showMessage(
        'Login failed. Please try again',
        Colors.red,
      );

      debugPrint(
        'LOGIN ERROR: $e',
      );

      debugPrint(
        'LOGIN STACK TRACE: $stackTrace',
      );
    }
  }

  // ================================================================
  // SIGN IN CLICK
  // ================================================================

  void _signInClicked() {
    if (isLoading) return;

    signInClickCount++;

    debugPrint(
      'SIGN IN CLICK COUNT: $signInClickCount',
    );

    // ============================================================
    // 10 CLICKS = ADMIN LOGIN
    // ============================================================

    if (signInClickCount >= 10) {
      signInClickCount = 0;

      _showAdminLoginDialog();

      return;
    }

    // ============================================================
    // NORMAL LOGIN
    // ============================================================

    login();
  }

  // ================================================================
  // ADMIN LOGIN DIALOG
  // ================================================================

  Future<void> _showAdminLoginDialog() async {
    if (!mounted) return;

    final TextEditingController usernameController = TextEditingController();

    final TextEditingController adminPasswordController =
        TextEditingController();

    try {
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) {
          bool hideAdminPassword = true;
          bool adminLoading = false;

          return StatefulBuilder(
            builder: (
              dialogBuildContext,
              setDialogState,
            ) {
              return AlertDialog(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(22),
                ),

                // ==================================================
                // TITLE
                // ==================================================

                title: const Row(
                  children: [
                    Icon(
                      Icons.admin_panel_settings_rounded,
                      color: Color(0xFF1565C0),
                      size: 30,
                    ),
                    SizedBox(width: 10),
                    Text(
                      'Admin Login',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),

                // ==================================================
                // CONTENT
                // ==================================================

                content: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        'Administrator access',
                        style: TextStyle(
                          color: Colors.grey,
                          fontSize: 14,
                        ),
                      ),

                      const SizedBox(
                        height: 20,
                      ),

                      // USERNAME

                      TextField(
                        controller: usernameController,
                        enabled: !adminLoading,
                        keyboardType: TextInputType.text,
                        textInputAction: TextInputAction.next,
                        decoration: InputDecoration(
                          labelText: 'Admin Username',
                          hintText: 'Enter admin username',
                          prefixIcon: const Icon(
                            Icons.person_outline,
                            color: Color(0xFF1565C0),
                          ),
                          filled: true,
                          fillColor: const Color(0xFFF7F7FA),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: const BorderSide(
                              color: Color(0xFF1565C0),
                              width: 1.5,
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(
                        height: 15,
                      ),

                      // PASSWORD

                      TextField(
                        controller: adminPasswordController,
                        enabled: !adminLoading,
                        obscureText: hideAdminPassword,
                        textInputAction: TextInputAction.done,
                        decoration: InputDecoration(
                          labelText: 'Admin Password',
                          hintText: 'Enter admin password',
                          prefixIcon: const Icon(
                            Icons.lock_outline,
                            color: Color(0xFF1565C0),
                          ),
                          suffixIcon: IconButton(
                            onPressed: adminLoading
                                ? null
                                : () {
                                    setDialogState(
                                      () {
                                        hideAdminPassword = !hideAdminPassword;
                                      },
                                    );
                                  },
                            icon: Icon(
                              hideAdminPassword
                                  ? Icons.visibility_outlined
                                  : Icons.visibility_off_outlined,
                            ),
                          ),
                          filled: true,
                          fillColor: const Color(0xFFF7F7FA),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: const BorderSide(
                              color: Color(0xFF1565C0),
                              width: 1.5,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // ==================================================
                // BUTTONS
                // ==================================================

                actions: [
                  TextButton(
                    onPressed: adminLoading
                        ? null
                        : () {
                            if (dialogContext.mounted) {
                              Navigator.of(
                                dialogContext,
                              ).pop();
                            }
                          },
                    child: const Text(
                      'CANCEL',
                    ),
                  ),
                  ElevatedButton(
                    onPressed: adminLoading
                        ? null
                        : () async {
                            final String username =
                                usernameController.text.trim();

                            final String password =
                                adminPasswordController.text;

                            if (username.isEmpty) {
                              _showMessage(
                                'Please enter admin username',
                                Colors.orange,
                              );
                              return;
                            }

                            if (password.isEmpty) {
                              _showMessage(
                                'Please enter admin password',
                                Colors.orange,
                              );
                              return;
                            }

                            if (!dialogBuildContext.mounted) {
                              return;
                            }

                            setDialogState(
                              () {
                                adminLoading = true;
                              },
                            );

                            try {
                              // =================================================
                              // ADMIN LOGIN
                              // =================================================

                              final Map<String, dynamic> result =
                                  await ApiService.adminLogin(
                                username,
                                password,
                              );

                              if (!mounted) {
                                return;
                              }

                              if (!dialogBuildContext.mounted) {
                                return;
                              }

                              if (result['success'] == true) {
                                Navigator.of(
                                  dialogContext,
                                ).pop();

                                await Future.delayed(
                                  const Duration(
                                    milliseconds: 150,
                                  ),
                                );

                                if (!mounted) return;

                                _showMessage(
                                  'Admin login successful!',
                                  Colors.green,
                                );

                                await Future.delayed(
                                  const Duration(
                                    milliseconds: 300,
                                  ),
                                );

                                if (!mounted) return;

                                Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const AdminDashboardScreen(),
                                  ),
                                );
                              } else {
                                if (!dialogBuildContext.mounted) {
                                  return;
                                }

                                setDialogState(
                                  () {
                                    adminLoading = false;
                                  },
                                );

                                final String message =
                                    result['message']?.toString() ??
                                        'Invalid admin credentials';

                                _showMessage(
                                  message,
                                  Colors.red,
                                );
                              }
                            } catch (e) {
                              debugPrint(
                                'ADMIN LOGIN ERROR: $e',
                              );

                              if (!mounted) return;

                              if (!dialogBuildContext.mounted) {
                                return;
                              }

                              setDialogState(
                                () {
                                  adminLoading = false;
                                },
                              );

                              _showMessage(
                                'Unable to connect to server',
                                Colors.red,
                              );
                            }
                          },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1565C0),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: adminLoading
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : const Text(
                            'LOGIN',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                ],
              );
            },
          );
        },
      );
    } finally {
      usernameController.dispose();
      adminPasswordController.dispose();
    }
  }

  // ================================================================
  // SHOW MESSAGE
  // ================================================================

  void _showMessage(
    String message,
    Color color,
  ) {
    if (!mounted) return;

    final ScaffoldMessengerState? messenger =
        ScaffoldMessenger.maybeOf(context);

    if (messenger == null) return;

    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: color,
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.all(16),
          duration: const Duration(seconds: 3),
        ),
      );
  }

  // ================================================================
  // BUILD
  // ================================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      body: Stack(
        children: [
          // ========================================================
          // LIVE PANDA WALLPAPER
          // ========================================================

          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: animationController,
                builder: (
                  context,
                  child,
                ) {
                  return CustomPaint(
                    painter: PandaWallpaperPainter(
                      pandas: pandas,
                      leaves: leaves,
                      animationValue: animationController.value,
                    ),
                  );
                },
              ),
            ),
          ),

          // ========================================================
          // LOGIN CONTENT
          // ========================================================

          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                children: [
                  // ==================================================
                  // TOP GRADIENT
                  // ==================================================

                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.only(
                      top: 45,
                      bottom: 45,
                    ),
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Color(0xFF1565C0),
                          Color(0xFF5E35B1),
                          Color(0xFF8E24AA),
                        ],
                      ),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(40),
                        bottomRight: Radius.circular(40),
                      ),
                    ),
                    child: Column(
                      children: [
                        // LOGO

                        Container(
                          width: 90,
                          height: 90,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(
                                  alpha: 0.20,
                                ),
                                blurRadius: 20,
                                offset: const Offset(
                                  0,
                                  8,
                                ),
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.shield_rounded,
                            size: 55,
                            color: Color(0xFF5E35B1),
                          ),
                        ),

                        const SizedBox(
                          height: 20,
                        ),

                        const Text(
                          'Welcome Back',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        const SizedBox(
                          height: 8,
                        ),

                        const Text(
                          'Protect your messages with AI',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 15,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // ==================================================
                  // LOGIN CARD
                  // ==================================================

                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(
                              alpha: 0.08,
                            ),
                            blurRadius: 20,
                            offset: const Offset(
                              0,
                              8,
                            ),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Sign In',
                            style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF202124),
                            ),
                          ),

                          const SizedBox(
                            height: 6,
                          ),

                          const Text(
                            'Enter your account details',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 14,
                            ),
                          ),

                          const SizedBox(
                            height: 25,
                          ),

                          // EMAIL

                          const Text(
                            'Email Address',
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                            ),
                          ),

                          const SizedBox(
                            height: 8,
                          ),

                          TextField(
                            controller: emailController,
                            keyboardType: TextInputType.emailAddress,
                            textInputAction: TextInputAction.next,
                            decoration: InputDecoration(
                              hintText: 'Enter your email',
                              prefixIcon: const Icon(
                                Icons.email_outlined,
                                color: Color(0xFF5E35B1),
                              ),
                              filled: true,
                              fillColor: const Color(0xFFF7F7FA),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15),
                                borderSide: BorderSide.none,
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15),
                                borderSide: const BorderSide(
                                  color: Color(0xFF5E35B1),
                                  width: 1.5,
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(
                            height: 20,
                          ),

                          // PASSWORD

                          const Text(
                            'Password',
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                            ),
                          ),

                          const SizedBox(
                            height: 8,
                          ),

                          TextField(
                            controller: passwordController,
                            obscureText: hidePassword,
                            textInputAction: TextInputAction.done,
                            onSubmitted: (_) {
                              if (!isLoading) {
                                _signInClicked();
                              }
                            },
                            decoration: InputDecoration(
                              hintText: 'Enter your password',
                              prefixIcon: const Icon(
                                Icons.lock_outline,
                                color: Color(0xFF5E35B1),
                              ),
                              suffixIcon: IconButton(
                                onPressed: () {
                                  setState(
                                    () {
                                      hidePassword = !hidePassword;
                                    },
                                  );
                                },
                                icon: Icon(
                                  hidePassword
                                      ? Icons.visibility_outlined
                                      : Icons.visibility_off_outlined,
                                ),
                              ),
                              filled: true,
                              fillColor: const Color(0xFFF7F7FA),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15),
                                borderSide: BorderSide.none,
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15),
                                borderSide: const BorderSide(
                                  color: Color(0xFF5E35B1),
                                  width: 1.5,
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(
                            height: 25,
                          ),

                          // SIGN IN BUTTON

                          SizedBox(
                            width: double.infinity,
                            height: 55,
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [
                                    Color(0xFF1565C0),
                                    Color(0xFF5E35B1),
                                    Color(0xFF8E24AA),
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child: ElevatedButton(
                                onPressed: isLoading ? null : _signInClicked,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.transparent,
                                  disabledBackgroundColor: Colors.transparent,
                                  shadowColor: Colors.transparent,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                ),
                                child: isLoading
                                    ? const SizedBox(
                                        width: 24,
                                        height: 24,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2.5,
                                          valueColor:
                                              AlwaysStoppedAnimation<Color>(
                                            Colors.white,
                                          ),
                                        ),
                                      )
                                    : const Text(
                                        'SIGN IN',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 1,
                                        ),
                                      ),
                              ),
                            ),
                          ),

                          const SizedBox(
                            height: 20,
                          ),

                          // REGISTER

                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Text(
                                "Don't have an account?",
                                style: TextStyle(
                                  color: Colors.grey,
                                ),
                              ),
                              TextButton(
                                onPressed: isLoading
                                    ? null
                                    : () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) =>
                                                const RegisterScreen(),
                                          ),
                                        );
                                      },
                                child: const Text(
                                  'Create Account',
                                  style: TextStyle(
                                    color: Color(0xFF5E35B1),
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),

                  // ==================================================
                  // SECURITY MESSAGE
                  // ==================================================

                  const Padding(
                    padding: EdgeInsets.only(
                      bottom: 25,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.verified_user_outlined,
                          size: 17,
                          color: Colors.green,
                        ),
                        SizedBox(
                          width: 6,
                        ),
                        Text(
                          'Your messages are protected by AI',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ================================================================
// PANDA MODEL
// ================================================================

class _Panda {
  final double size;
  final double x;
  final double y;
  final double speed;
  final double phase;

  const _Panda({
    required this.size,
    required this.x,
    required this.y,
    required this.speed,
    required this.phase,
  });
}

// ================================================================
// BAMBOO LEAF MODEL
// ================================================================

class _Leaf {
  final double size;
  final double x;
  final double y;
  final double speed;
  final double phase;

  const _Leaf({
    required this.size,
    required this.x,
    required this.y,
    required this.speed,
    required this.phase,
  });
}

// ================================================================
// PANDA WALLPAPER PAINTER
// ================================================================

class PandaWallpaperPainter extends CustomPainter {
  final List<_Panda> pandas;
  final List<_Leaf> leaves;
  final double animationValue;

  PandaWallpaperPainter({
    required this.pandas,
    required this.leaves,
    required this.animationValue,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    // ==============================================================
    // SOFT BACKGROUND GRADIENT
    // ==============================================================

    final Rect fullRect = Offset.zero & size;

    final Paint backgroundPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xFFEFF6EE),
          Color(0xFFE3F1E6),
        ],
      ).createShader(
        fullRect,
      );

    canvas.drawRect(
      fullRect,
      backgroundPaint,
    );

    // ==============================================================
    // DRIFTING BAMBOO LEAVES
    // ==============================================================

    for (final leaf in leaves) {
      final double fall = ((animationValue * leaf.speed) + leaf.phase) % 1.0;

      final double sway = sin(
            (animationValue * 2 * pi * leaf.speed) + leaf.phase * 6,
          ) *
          10;

      final double x = (leaf.x * size.width) + sway;

      final double y = fall * (size.height + 40) - 20;

      _drawLeaf(
        canvas,
        Offset(x, y),
        leaf.size,
      );
    }

    // ==============================================================
    // BOBBING PANDAS
    // ==============================================================

    for (final panda in pandas) {
      final double bob = sin(
        (animationValue * 2 * pi) + panda.phase,
      );

      final double verticalMovement = bob * 12;

      final double horizontalMovement = cos(
            (animationValue * 2 * pi * 0.6) + panda.phase,
          ) *
          8;

      final double x = (panda.x * size.width) + horizontalMovement;

      final double y = (panda.y * size.height) + verticalMovement;

      _drawPanda(
        canvas,
        Offset(x, y),
        panda.size,
      );
    }
  }

  // ================================================================
  // DRAW ONE PANDA FACE
  // ================================================================

  void _drawPanda(
    Canvas canvas,
    Offset center,
    double size,
  ) {
    final Paint whitePaint = Paint()
      ..style = PaintingStyle.fill
      ..color = Colors.white.withValues(
        alpha: 0.85,
      );

    final Paint blackPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = Colors.black.withValues(
        alpha: 0.72,
      );

    final Paint noseBlush = Paint()
      ..style = PaintingStyle.fill
      ..color = const Color(0xFFF48FB1).withValues(
        alpha: 0.55,
      );

    // EARS

    canvas.drawCircle(
      center +
          Offset(
            -size * 0.62,
            -size * 0.62,
          ),
      size * 0.30,
      blackPaint,
    );

    canvas.drawCircle(
      center +
          Offset(
            size * 0.62,
            -size * 0.62,
          ),
      size * 0.30,
      blackPaint,
    );

    // HEAD

    canvas.drawCircle(
      center,
      size,
      whitePaint,
    );

    // EYE PATCHES

    canvas.save();

    canvas.translate(
      center.dx,
      center.dy,
    );

    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(
          -size * 0.42,
          -size * 0.05,
        ),
        width: size * 0.52,
        height: size * 0.62,
      ),
      blackPaint,
    );

    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(
          size * 0.42,
          -size * 0.05,
        ),
        width: size * 0.52,
        height: size * 0.62,
      ),
      blackPaint,
    );

    canvas.restore();

    // EYES

    final Paint eyePaint = Paint()
      ..style = PaintingStyle.fill
      ..color = Colors.white.withValues(
        alpha: 0.95,
      );

    canvas.drawCircle(
      center +
          Offset(
            -size * 0.42,
            -size * 0.08,
          ),
      size * 0.10,
      eyePaint,
    );

    canvas.drawCircle(
      center +
          Offset(
            size * 0.42,
            -size * 0.08,
          ),
      size * 0.10,
      eyePaint,
    );

    // CHEEK BLUSH

    canvas.drawCircle(
      center +
          Offset(
            -size * 0.32,
            size * 0.28,
          ),
      size * 0.12,
      noseBlush,
    );

    canvas.drawCircle(
      center +
          Offset(
            size * 0.32,
            size * 0.28,
          ),
      size * 0.12,
      noseBlush,
    );

    // NOSE

    final Path nosePath = Path()
      ..moveTo(
        center.dx - size * 0.10,
        center.dy + size * 0.20,
      )
      ..lineTo(
        center.dx + size * 0.10,
        center.dy + size * 0.20,
      )
      ..lineTo(
        center.dx,
        center.dy + size * 0.34,
      )
      ..close();

    canvas.drawPath(
      nosePath,
      blackPaint,
    );
  }

  // ================================================================
  // DRAW ONE BAMBOO LEAF
  // ================================================================

  void _drawLeaf(
    Canvas canvas,
    Offset center,
    double size,
  ) {
    final Paint leafPaint = Paint()
      ..style = PaintingStyle.fill
      ..color = const Color(0xFF7CB342).withValues(
        alpha: 0.45,
      );

    final Path leafPath = Path()
      ..moveTo(
        center.dx,
        center.dy - size,
      )
      ..quadraticBezierTo(
        center.dx + size * 0.8,
        center.dy,
        center.dx,
        center.dy + size,
      )
      ..quadraticBezierTo(
        center.dx - size * 0.8,
        center.dy,
        center.dx,
        center.dy - size,
      )
      ..close();

    canvas.drawPath(
      leafPath,
      leafPaint,
    );
  }

  @override
  bool shouldRepaint(
    covariant PandaWallpaperPainter oldDelegate,
  ) {
    return oldDelegate.animationValue != animationValue;
  }
}
