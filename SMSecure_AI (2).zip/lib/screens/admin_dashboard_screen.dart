import 'package:flutter/material.dart';

import '../services/api_service.dart';
import '../screens/login_screen.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  bool isLoading = true;
  bool isRefreshing = false;

  int totalUsers = 0;
  int totalPredictions = 0;

  DateTime? lastUpdated;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        loadStatistics();
      }
    });
  }

  // ============================================================
  // LOAD STATISTICS
  // ============================================================

  Future<void> loadStatistics({
    bool refresh = false,
  }) async {
    if (!mounted) return;

    if (refresh) {
      setState(() {
        isRefreshing = true;
      });
    } else {
      setState(() {
        isLoading = true;
      });
    }

    try {
      final Map<String, dynamic> result = await ApiService.getAdminStats();

      if (!mounted) return;

      if (result["success"] == true) {
        final dynamic responseData = result["data"];

        if (responseData is! Map) {
          setState(() {
            isLoading = false;
            isRefreshing = false;
          });

          _showMessage(
            "Invalid statistics received from server",
            Colors.red,
          );

          return;
        }

        final Map<dynamic, dynamic> data = responseData;

        final int newTotalUsers = _toInt(data["total_users"]);

        final int newTotalPredictions = _toInt(data["total_predictions"]);

        if (!mounted) return;

        setState(() {
          totalUsers = newTotalUsers;
          totalPredictions = newTotalPredictions;

          isLoading = false;
          isRefreshing = false;

          lastUpdated = DateTime.now();
        });

        if (refresh) {
          _showMessage(
            "Statistics refreshed",
            Colors.green,
          );
        }
      } else {
        if (!mounted) return;

        setState(() {
          isLoading = false;
          isRefreshing = false;
        });

        _showMessage(
          result["message"]?.toString() ?? "Failed to load statistics",
          Colors.red,
        );
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isLoading = false;
        isRefreshing = false;
      });

      debugPrint(
        "ADMIN STATISTICS ERROR: $e",
      );

      _showMessage(
        "Unable to connect to server",
        Colors.red,
      );
    }
  }

  // ============================================================
  // CONVERT VALUE TO INT
  // ============================================================

  int _toInt(dynamic value) {
    if (value == null) {
      return 0;
    }

    if (value is int) {
      return value;
    }

    if (value is double) {
      return value.toInt();
    }

    if (value is num) {
      return value.toInt();
    }

    return int.tryParse(
          value.toString(),
        ) ??
        0;
  }

  // ============================================================
  // SHOW MESSAGE
  // ============================================================

  void _showMessage(
    String message,
    Color color,
  ) {
    if (!mounted) return;

    final ScaffoldMessengerState? messenger =
        ScaffoldMessenger.maybeOf(context);

    if (messenger == null) return;

    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: color,
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.all(16),
          duration: const Duration(seconds: 2),
        ),
      );
  }

  // ============================================================
  // LOGOUT
  // ============================================================

  void logout() {
    if (!mounted) return;

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(
        builder: (context) => const LoginScreen(),
      ),
      (Route<dynamic> route) => false,
    );
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),

      // ========================================================
      // APP BAR
      // ========================================================

      appBar: AppBar(
        elevation: 0,
        backgroundColor: const Color(0xFF1565C0),
        foregroundColor: Colors.white,
        title: const Row(
          children: [
            Icon(
              Icons.admin_panel_settings_rounded,
              size: 28,
            ),
            SizedBox(width: 10),
            Text(
              "Admin Dashboard",
              style: TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        actions: [
          // ====================================================
          // REFRESH
          // ====================================================

          IconButton(
            onPressed: isRefreshing
                ? null
                : () {
                    loadStatistics(
                      refresh: true,
                    );
                  },
            tooltip: "Refresh",
            icon: isRefreshing
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2,
                    ),
                  )
                : const Icon(
                    Icons.refresh_rounded,
                  ),
          ),

          // ====================================================
          // LOGOUT
          // ====================================================

          IconButton(
            onPressed: logout,
            tooltip: "Logout",
            icon: const Icon(
              Icons.logout_rounded,
            ),
          ),
        ],
      ),

      // ========================================================
      // BODY
      // ========================================================

      body: RefreshIndicator(
        color: const Color(0xFF1565C0),
        onRefresh: () async {
          await loadStatistics(
            refresh: true,
          );
        },
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ==================================================
              // HEADER
              // ==================================================

              const Text(
                "Welcome, Admin 👋",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF202124),
                ),
              ),

              const SizedBox(height: 6),

              const Text(
                "Monitor your SMSecure AI application",
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 15,
                ),
              ),

              const SizedBox(height: 8),

              // ==================================================
              // LAST UPDATED
              // ==================================================

              if (lastUpdated != null)
                Row(
                  children: [
                    const Icon(
                      Icons.access_time_rounded,
                      size: 15,
                      color: Colors.grey,
                    ),
                    const SizedBox(width: 5),
                    Text(
                      "Updated ${_formatTime(lastUpdated!)}",
                      style: const TextStyle(
                        color: Colors.grey,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),

              const SizedBox(height: 25),

              // ==================================================
              // LOADING
              // ==================================================

              if (isLoading)
                _buildLoading()
              else ...[
                // ================================================
                // TOTAL USERS
                // ================================================

                _buildMainCard(
                  title: "Total Users",
                  value: totalUsers.toString(),
                  subtitle: "Registered users",
                  icon: Icons.people_alt_rounded,
                  color: const Color(0xFF1565C0),
                ),

                const SizedBox(height: 15),

                // ================================================
                // TOTAL PREDICTIONS
                // ================================================

                _buildMainCard(
                  title: "Total Predictions",
                  value: totalPredictions.toString(),
                  subtitle: "Messages analyzed",
                  icon: Icons.analytics_rounded,
                  color: const Color(0xFF5E35B1),
                ),

                const SizedBox(height: 25),

                // ================================================
                // LIVE STATISTICS
                // ================================================

                _buildLiveStatistics(),

                const SizedBox(height: 30),

                // ================================================
                // FOOTER
                // ================================================

                const Center(
                  child: Text(
                    "SMSecure AI • Admin Panel",
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 12,
                    ),
                  ),
                ),

                const SizedBox(height: 20),
              ],
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // LOADING
  // ============================================================

  Widget _buildLoading() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(45),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
      ),
      child: const Column(
        children: [
          CircularProgressIndicator(
            color: Color(0xFF1565C0),
          ),
          SizedBox(height: 20),
          Text(
            "Loading statistics...",
            style: TextStyle(
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // MAIN CARD
  // ============================================================

  Widget _buildMainCard({
    required String title,
    required String value,
    required String subtitle,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          // ICON

          Container(
            width: 62,
            height: 62,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(
              icon,
              color: color,
              size: 32,
            ),
          ),

          const SizedBox(width: 18),

          // TEXT

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.grey,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: Colors.grey,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // LIVE STATISTICS CARD
  // ============================================================

  Widget _buildLiveStatistics() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // HEADER

          const Row(
            children: [
              Icon(
                Icons.dashboard_rounded,
                color: Color(0xFF1565C0),
              ),
              SizedBox(width: 10),
              Text(
                "Live Statistics",
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),

          const SizedBox(height: 20),

          // USERS

          _buildLiveRow(
            "Registered Users",
            totalUsers,
            Icons.people_rounded,
            const Color(0xFF1565C0),
          ),

          const Divider(height: 25),

          // PREDICTIONS

          _buildLiveRow(
            "Messages Analyzed",
            totalPredictions,
            Icons.message_rounded,
            const Color(0xFF5E35B1),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // LIVE ROW
  // ============================================================

  Widget _buildLiveRow(
    String title,
    int value,
    IconData icon,
    Color color,
  ) {
    return Row(
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.10),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: color,
            size: 22,
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Text(
          value.toString(),
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // FORMAT TIME
  // ============================================================

  String _formatTime(
    DateTime time,
  ) {
    final int hour = time.hour % 12 == 0 ? 12 : time.hour % 12;

    final String minute = time.minute.toString().padLeft(2, '0');

    final String period = time.hour >= 12 ? "PM" : "AM";

    return "$hour:$minute $period";
  }
}
